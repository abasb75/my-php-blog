<div id="welcome">
    <div id="home-welecome-bg" style="filter:blur(0px);transform:scale(1);">
        <img width="1200" height="600" src="/asset/image/gols.jpg" alt="وب سایت شخصی عباس باقری">
    </div>
    <div id="particles-js">
        <canvas class="particles-js-canvas-el" width="731" height="701" style="width: 100%; height: 100%;"></canvas>
    </div>
    <div class="cover"> </div>
    <div class="home-welcome-cover" id="home-welcome-cover">
        <div id="welcome-card">
            <p>سلام!</p>
            <h1>به وب سایت شخصی عباس باقری ، مهندس نرم‌افزار و توسعه دهنده ارشد وب خوش آمدید.</h1>
            <div id="welcome-buttons">
                <ul>
                    <li><a onclick="gotoSection(event)" href="#about-me">درباره من</a></li>
                    <li><a onclick="gotoSection(event)" href="#my-jobs">سوابق شغلی</a></li>
                    <li><a onclick="gotoSection(event)" href="#my-skills">مهارتهای‌من</a></li>
                    <li><a onclick="gotoSection(event)" href="#contact-me">راه‌های ارتباطی</a></li>
                    <li><a onclick="gotoSection(event)" href="#home-latest-post">نوشته‌های اخیر</a></li>
                </ul>
            </div>
        </div>
        <div id="welcome-sosial-link">
            <span>در شبکه‌های اجتماعی: </span>
            <ul>
                <li><a href="https://telegram.me/989015827703" title="تلگرام"><i class="icon-telegram"></i></a></li>
                <li><a href="https://github.com/abasb75" title="گیتهاب"><i class="icon-github"></i></a></li>
                <li><a href="https://virgool.io/@abasb75" title="ویرگول"><i class="icon-virgool"></i></a></li>
                <li><a href="https://wa.me/989015827703" title="واتساپ"><i class="icon-whatsapp"></i></a></li>
                <li><a href="https://ble.ir/abasb75" title="پیامرسان بله"><i class="icon-bale"></i></a></li>
            </ul>
        </div>
    </div>
</div>