<div id="big-spiner" class="show">
    <div class="image-holder">
        <img src="/asset/loading/main-loading.svg" alt="وب سایت عباس باقری" width="200" height="200">
    </div>
</div>
            