<footer id="footer">
    <div class="footer-content">
        <div class="footer-div">
            <p>عباس باقری - برنامه نویس وب</p>
        </div>
        <div class="footer-div">
            <ul>
                <li>
                    <a href="https://ictroshd.sums.ac.ir/page-ITIC/fa/171/form/pId65980" target="_blank">تیوان شیراز</a>
                </li>
                <li>• </li>
                <li>
                    <a href="/rss" target="_blank">RSS</a>
                </li>
                <li>• </li>
                <li>
                    <a href="https://github.com/abasb75" target="_blank">گیتهاب</a>
                </li>
            </ul>
        </div>
    </div>
</footer>